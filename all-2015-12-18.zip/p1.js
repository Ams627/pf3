a = [{"journey": [
 {"orig": "Q202", "dest": "Q083", "route": "00000", "flow": "478938", "fares": [

{"ticketcode": "7DF", "adult": "35050", "child": "35050", "rescode": "  "},
{"ticketcode": "7DS", "adult": "17380", "child": "17380", "rescode": "  "},
{"ticketcode": "CDR", "adult": "4860", "child": "4860", "rescode": "B3"},
{"ticketcode": "CDS", "adult": "4850", "child": "4850", "rescode": "B3"},
{"ticketcode": "FDR", "adult": "11930", "child": "11930", "rescode": "  "},
{"ticketcode": "FDS", "adult": "9170", "child": "9170", "rescode": "  "},
{"ticketcode": "SDR", "adult": "5180", "child": "5180", "rescode": "  "},
{"ticketcode": "SDS", "adult": "5170", "child": "5170", "rescode": "  "},
{"ticketcode": "SVR", "adult": "6160", "child": "6160", "rescode": "5K"},
]},
 {"orig": "QA20", "dest": "QA91", "route": "00439", "flow": "792297", "fares": [

{"ticketcode": "MAS", "adult": "2630", "child": "2630", "rescode": "XV"},
{"ticketcode": "MBS", "adult": "2110", "child": "2110", "rescode": "XV"},
{"ticketcode": "MCS", "adult": "1680", "child": "1680", "rescode": "XV"},
{"ticketcode": "MFS", "adult": "4890", "child": "4890", "rescode": "XV"},
{"ticketcode": "MGS", "adult": "4390", "child": "4390", "rescode": "XV"},
{"ticketcode": "MHS", "adult": "3910", "child": "3910", "rescode": "XV"},
]}, ]}
