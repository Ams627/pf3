#pragma once

void DebugDumpFares() {};