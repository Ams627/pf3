#include "stdafx.h"
#include "PrintProgress.h"

long PrintProgress::globalLineNumber_ = 0;
