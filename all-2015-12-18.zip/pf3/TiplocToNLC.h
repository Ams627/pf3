#pragma once

std::string GetCRS(std::string tiploc);
void GetCRSSet(std::set<std::string>& crsset);

