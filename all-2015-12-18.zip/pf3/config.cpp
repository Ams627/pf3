#include "stdafx.h"
#include "config.h"

namespace Config
{
    Directories directories;
}