a = {
    "tech": {
        "serverutc": 14473658063774081,
        "serverCPU": 147,
        "computerID": "F4C708E3-FF01-4A97-902F-1778C61B75B6"
    },
    "fares": {
        "ftec": {
            "version": 989,
            "ndfVersion": 822
        },
        "result": [
           {
               "rlc": "   ",
               "plusbus": {
                   "o": "5883",
                   "d": "3115",
                   "po": "H132",
                   "pd": "J931",
                   "fares": {

                   }
               },
               "flows": [
                  {
                      "o": "Q202",
                      "d": "Q083",
                      "route": "00000",
                      "fares": [
                         {
                             "a": 35050,
                             "c": 17525,
                             "t": "7DF",
                             "r": "  "
                         },
                         {
                             "a": 17380,
                             "c": 8690,
                             "t": "7DS",
                             "r": "  "
                         },
                      ]
                  }
               ]

           }
        ]
    }
}