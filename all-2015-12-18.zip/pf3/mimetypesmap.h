#pragma once

extern std::string GetMimeType(std::string);