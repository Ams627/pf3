// #define _USING_V110_SDK71_
#include "stdafx.h"

// tell the linker to link with winsock 2 and iphelper API libs:
#pragma comment(lib,"ws2_32.lib")
#pragma comment(lib,"Iphlpapi.lib")
